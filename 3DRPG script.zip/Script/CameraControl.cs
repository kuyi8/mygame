using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControl : MonoBehaviour
{
    private Transform player;
    //[Header("����Ŀ��")]
    //public Transform target;
    //
    //[Header("λ��ƫ�� (���Ŀ��)")]
    //public Vector3 positionOffset = new Vector3(0, 5, -10);
    //
    //[Header("�Ƕ�ƫ�� (ŷ����)")]
    //public Vector3 rotationOffset = new Vector3(15, 0, 0);
    //
    //[Header("����ƽ��")]
    //public float smoothSpeed = 5f;
    //public Vector3 targetLocalPos = new Vector3(0f, 3f, -5f);
    //public Vector3 targetLocalRot = new Vector3(15f, 0f, 0f);
    //public float smoothSpeed = 8f;
    void Start()
    {
        player = transform.parent;
        Cursor.lockState = CursorLockMode.Locked;
    }

   
    void Update()
    {
        var x = InputManager.Instance.Camera.x;

        transform.RotateAround(player.position,player.up, x * 180 * Time.deltaTime);
    }
   //private void LateUpdate()
   //{
   //    // ƽ���ƶ��ֲ�λ��
   //    transform.localPosition = Vector3.Lerp(transform.localPosition, targetLocalPos, smoothSpeed * Time.deltaTime);
   //    // ƽ����ת�ֲ���ת
   //    Quaternion targetRot = Quaternion.Euler(targetLocalRot);
   //    transform.localRotation = Quaternion.Slerp(transform.localRotation, targetRot, smoothSpeed * Time.deltaTime);
   //}
}
