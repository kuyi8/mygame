using UnityEngine;

public class FootStepEvent : MonoBehaviour
{
    public void FootL()
    {
        // ������
        //Debug.Log("Left Foot");
    }

    public void FootR()
    {
        // �ҽ����
        //Debug.Log("Right Foot");
    }
}