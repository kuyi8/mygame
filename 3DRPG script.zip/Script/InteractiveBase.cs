using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InteractiveBase : MonoBehaviour
{
    public virtual void Use()
    {
        Debug.Log("ʹ��");
    }
}
