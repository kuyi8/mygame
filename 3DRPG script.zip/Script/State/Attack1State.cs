using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attack1State : StateBase
{
    private void OnEnable()
    {
        player.GetHit(3);
        Debug.Log(player.Hp);
    }
}
