using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DieState : StateBase
{
    public GameObject Healing;
    float time;
    private void OnEnable()
    {
        //�����ܲ�����
        animator.SetBool("Die", true);
        //Healing.SetActive(true);
    }

    private void OnDisable()
    {
        //�����ܲ�����
        animator.SetBool("Die", false);
        Healing.SetActive(false);
        player.Hp = player.MaxHp;
    }
    void Start()
    {
        time = 0f;
    }

    // Update is called once per frame
    void Update()
    {
        time += Time.deltaTime;
        if (time > 1f)
        {
            Healing.SetActive(true);
        }

        if (time > 5f)
        {
            ChangeState<IdleState>();
        }
    }
}
