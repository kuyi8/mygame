using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameUIManager : MonoBehaviour
{
    [Header("��ť")]
    [SerializeField] private Button refreshButton;
    [SerializeField] private Button settingsButton;
    [SerializeField] private Button startMenuButton;

    [Header("�������")]
    [SerializeField] private GameObject settingsPanel;
    [SerializeField] private Slider volumeSlider;
    [SerializeField] private Button exitGameButton;
    [SerializeField] private Button closePanelButton;

    //[Header("ˢ��ȷ��")]
    //[SerializeField] private GameObject confirmPanel;  // ��ѡ��ȷ�����
    //[SerializeField] private Button confirmYesButton;
    //[SerializeField] private Button confirmNoButton;

    private AudioSource bgmAudio;

    private float currentVolume = 1f;

    void Start()
    {
        bgmAudio = GameObject.Find("AudioPlayer").GetComponent<AudioSource>();

        // �󶨰�ť�¼�
        refreshButton.onClick.AddListener(OnRefreshClick);
        settingsButton.onClick.AddListener(OnSettingsClick);
        exitGameButton.onClick.AddListener(OnExitGame);
        startMenuButton.onClick.AddListener(OnStartMenu);
        closePanelButton.onClick.AddListener(CloseSettingsPanel);

        // ����������
        volumeSlider.onValueChanged.AddListener(OnVolumeChanged);

        // ���ر������������
        LoadSettings();

        // ��ʼ�ر��������
        if (settingsPanel != null)
            settingsPanel.SetActive(false);

        // ȷ����壨��ѡ��
        //if (confirmPanel != null)
        //    confirmPanel.SetActive(false);
    }

    // ˢ�°�ť���
    void OnRefreshClick()
    {
        // ��ʽ1��ֱ��������������򵥣�
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);

        // ��ʽ2������ȷ����壨��ֹ�󴥣�
        // if (confirmPanel != null)
        //     confirmPanel.SetActive(true);
    }

    // ȷ��ˢ��
    void ConfirmRefresh()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    // ȡ��ˢ��
    //void CancelRefresh()
    //{
    //    if (confirmPanel != null)
    //        confirmPanel.SetActive(false);
    //}

    // ���ð�ť���
    void OnSettingsClick()
    {
        if (settingsPanel != null)
            settingsPanel.SetActive(true);
    }

    // �ر��������
    void CloseSettingsPanel()
    {
        if (settingsPanel != null)
            settingsPanel.SetActive(false);
    }

    // �����ı�
    void OnVolumeChanged(float value)
    {
        currentVolume = value;
        if (bgmAudio != null)
            bgmAudio.volume = currentVolume;
        PlayerPrefs.SetFloat("GameVolume", currentVolume);
    }

    // �˳���Ϸ
    void OnExitGame()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
    }

    void OnStartMenu()
    {
        SceneManager.LoadScene("startMenu");
    }

    // ��������
    void LoadSettings()
    {
        if (PlayerPrefs.HasKey("GameVolume"))
        {
            currentVolume = PlayerPrefs.GetFloat("GameVolume");
            volumeSlider.value = currentVolume;
            AudioListener.volume = currentVolume;
        }
    }
}
